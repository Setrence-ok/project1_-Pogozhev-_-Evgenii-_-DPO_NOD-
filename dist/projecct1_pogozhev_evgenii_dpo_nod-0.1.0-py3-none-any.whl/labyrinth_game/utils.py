# labyrinth_game/utils.py

from constants import rooms


def describe_current_room(game_state):
    room = {}
    for k, v in game_state.items():
        if k == 'current_room':
            room = game_state.get(k)
            print(f"== {room.upper()} ==")
    for v in rooms[room]:
        match v:
            case 0:
                return print(f"{v}")
            case 1:
                return print(f"{v}")
            case 2:
                return print(f"{v}")
            case 3:
                return print(f"{v}")
