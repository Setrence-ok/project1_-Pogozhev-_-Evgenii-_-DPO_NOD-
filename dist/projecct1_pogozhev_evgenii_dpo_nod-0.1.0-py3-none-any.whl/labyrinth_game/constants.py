# labyrinth_game/constants.py

import copy

ROOMS = {
    'entrance': {
        'description': 'Вы в темном входе в лабиринт. Стены покрыты мхом. На полу лежит старый факел.',
        'exits': {'north': 'hall', 'east': 'trap_room'},
        'items': ['torch'],
        'puzzle': None
    },
    'hall': {
        'description': 'Большой зал с эхом. По центру стоит пьедестал с запечатанным сундуком.',
        'exits': {'south': 'entrance', 'west': 'library', 'north': 'treasure_room'},
        'items': ["treasure_key"],
        'puzzle': ('На пьедестале надпись: "Назовите число, которое идет после девяти". Введите ответ цифрой или словом.', '10')
    },
    'trap_room': {
          'description': 'Комната с хитрой плиточной поломкой. На стене видна надпись: "Осторожно — ловушка".',
          'exits': {'west': 'entrance', 'north': 'outpatient'},
          'items': ['rusty_key'],
          'puzzle': ('Система плит активна. Чтобы пройти, назовите слово "шаг" три раза подряд (введите "шаг шаг шаг")', 'шаг шаг шаг')
    },
    'library': {
          'description': 'Пыльная библиотека. На полках старые свитки. Где-то здесь может быть ключ от сокровищницы.',
          'exits': {'east': 'hall', 'north': 'armory'},
          'items': ['ancient_book'],
          'puzzle': ('В одном свитке загадка: "Что растет, когда его съедают?" (ответ одно слово)', 'резонанс')
    },
    'armory': {
          'description': 'Старая оружейная комната. На стене висит меч, рядом — небольшая бронзовая шкатулка.',
          'exits': {'south': 'library'},
          'items': ['sword', 'bronze_box'],
          'puzzle': None
    },
    'treasure_room': {
          'description': 'Комната, на столе большой сундук. Дверь заперта — нужен особый ключ.',
          'exits': {'south': 'hall'},
          'items': ['treasure_chest'],
          'puzzle': ('Дверь защищена кодом. Введите код (подсказка: это число пятикратного шага, 2*5= ? )', '10')
    },
    'outpatient': {
          'description': 'Комната, на кушетке стоит чемоданчик с лекарствами. Чемоданчик на кодовом замке.',
          'exits': {'south': 'trap_room', 'east': 'shop'},
          'items': ['first_aid_kit'],
          'puzzle': ('Чемоданчик с лекарствами защищена кодом. Введите код (подсказка: это количество месяцев в году )', '12')
    },
    'shop': {
        'description': 'Магазин редкой и деликатесной пищи. На витрине стоит свежеприготовленный снежный краб ',
        'exits': {'west': 'outpatient'},
        'items': ['snow_crab'],
        'puzzle': ('Напишите название профессии человека, который стоит за прилавком?', 'Продавец')
    }
}

GAME_STATE = {
    'player_inventory': [],  # Инвентарь игрока
    'current_room': 'entrance',  # Текущая комната
    'game_over': False,  # Значения окончания игры
    'steps_taken': 0  # Количество шагов
}

rooms = copy.deepcopy(ROOMS)
game_state = copy.deepcopy(GAME_STATE)